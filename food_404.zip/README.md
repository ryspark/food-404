# Food-404

Food-404 is the largest public food image dataset, with over 428,000 images and 404 food categories. It is a compilation of several other well-known food image datasets, including ETHZ Food-101, UEC-FOOD-256, UPMC-FOOD-101, and UMPC-Food-101, as well as images crawled from Google Image search results. Due to its heterogeneous nature, it contains food images from around the globe, including food native to Japanese, Italian, French, American, British, Chinese, Korean, Indonesian, Hawaiian, and Indian cultures.

Created at PennApps 2019f by machine learning back-end designer, Ryan Park, for entry "AI Allergy".


## Construction

Food-404 was created by compiling different food image datasets and crawling images from the web. This data was then tweaked by automatic and human process to ensure diversity and eliminate repetitive classes.


## Datasets used

- ETHZ Food-101 (https://www.vision.ee.ethz.ch/datasets_extra/food-101/)
- Foodx-251 (https://www.kaggle.com/c/ifood-2019-fgvc6/overview)
- UEC-FOOD-101 (http://foodcam.mobi/dataset100.html)
- UEC-FOOD-256 (http://foodcam.mobi/dataset256.html)
- Fruit recognition (https://zenodo.org/record/1310165#.XWzzfnVKgaz)
- UPMC-Food-101 (http://visiir.lip6.fr/#demo)
- Google Images (http://images.google.com)


## Structure

food-404/
    images/
        <class_name>/
            <image_id>.jpg
    classes.txt
    README.md


## Download

Please cite this page if you are using this dataset.
